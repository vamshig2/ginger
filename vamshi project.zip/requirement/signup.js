var employeeData;

fetch('dummy.json')
    .then(response => response.json())
    .then(data => {
        employeeData = data;
    })
    .catch(error => console.error('Error fetching data:', error));

document.getElementById('name').addEventListener('input', function () {
    validation_name();
});
document.getElementById('mobile').addEventListener('input', function () {
    validation_mobile();
});
document.getElementById('email').addEventListener('input', function () {
    validation_email();
});
document.getElementById('password').addEventListener('input', function () {
    validation_password();
});
document.getElementById('confirmPassword').addEventListener('input', function () {
    validation_confirmPassword();
});


let errorN = document.getElementById("errorN")
function validation_name() {
    let name = document.getElementById('name').value;
    let lettersOnly = /^[A-Za-z\s]+$/;
    if (name === '') {
        errorN.innerHTML = '*Name should not be Empty'
    } else if (isFinite(name)) {
        errorN.innerHTML = '*Name does not allow numbers'
    } else if (lettersOnly.test(name)) {
        errorN.innerHTML = ''
    } else {
        errorN.innerHTML = '*Special Charecters are not allowed for name'
    }
}

let errorM = document.getElementById("errorM")
function validation_mobile() {
    let mobile = document.getElementById('mobile').value;
    if ((mobile.length !== 10) && (mobile !== '')) {
        errorM.innerHTML = '*Enter a valid mobile number';
    }
    else if (mobile === '') {
        errorM.innerHTML = '*Mobile is mandatory';
    } else {
        errorM.innerHTML = '';
    }
}

let errorE = document.getElementById("errorE");
function validation_email() {
    var email = document.getElementById("email").value;
    let emailregex =  /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email===""){
        errorE.innerHTML ="*Email should not be empty";
    }
    if (emailregex.test(email)){
        errorE.innerHTML = '';
    }
    errorE.innerHTML = '';
}

let errorP = document.getElementById("errorP")
function validation_password() {
    let password = document.getElementById('password').value;
    if (password === '') {
        errorP.innerHTML = '* Password should not be empty';
    }else if (password.length < 4) {
        errorP.innerHTML = '* Password must be at least 4 characters long';
    }else if (password.length > 16) {
        errorP.innerHTML = '* Password should not contain more than 16 characters';
    }else if (!/[A-Z]/.test(password)) {
        errorP.innerHTML = '* Password must contain at least one uppercase letter';
    }else if (!/[a-z]/.test(password)) {
        errorP.innerHTML = '* Password must contain at least one lowercase letter';
    }else if (!/\d/.test(password)) {
        errorP.innerHTML = '* Password must contain at least one digit';
    }else if (!/[$@$!%*?&]/.test(password)) {
        errorP.innerHTML = '* Password must contain at least one special character ($@$!%*?&)';
    }else{
        errorP.innerHTML = '';
    }
}

let errorC = document.getElementById("errorC")
function validation_confirmPassword(){
    let password = document.getElementById('password').value;
    let confirmPassword = document.getElementById('confirmPassword').value;
    if (password === confirmPassword){
        errorC.innerHTML = '';
    }else{
        errorC.innerHTML = 'Password does not matched';
    }
}


function signup() {
    if (errorN.innerHTML === '' && errorM.innerHTML === '' && errorE.innerHTML === '' && errorP.innerHTML === '' && errorC.innerHTML === '') {
        alert("SignUp Successful Please SignIn");
        window.location.href = "signin.html";
    }
    let emails = document.getElementById('email').value;
    let data3 = { logemails : emails};
    localStorage.setItem('InLogemail', JSON.stringify(data3));

    let passwords = document.getElementById('password').value;
    let data4 = { logpasswords : passwords};
    localStorage.setItem('InLogpassword', JSON.stringify(data4));


    let names = document.getElementById('name').value;
    let data5 = { logname: names };
    localStorage.setItem('Innames', JSON.stringify(data5));
    
    let mobiles = document.getElementById('mobile').value;
    let data6 = {logmobiles:mobiles};
    localStorage.setItem('Inmobile', JSON.stringify(data6));

    let ages = document.getElementById('age').value;
    let data7 = {logages:ages};
    localStorage.setItem('Inage', JSON.stringify(data7));

    let dob = document.getElementById('dob').value;
    let data8 = {logdob:dob};
    localStorage.setItem('Indob', JSON.stringify(data8));
}
document.getElementById('signup').addEventListener('click', function() {
    signup();
});

