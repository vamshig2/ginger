var employeeData;
let editedEmployeeIndex;

let editDiallogBoxElement = document.getElementById('editDiallogBox');
let editSuccessMsgElement = document.createElement('p');
editSuccessMsgElement.style.margin = 0 + "px";


let email = document.getElementById('email').value;
let emailData = localStorage.getItem('InLogemail');
let emailsData = JSON.parse(emailData);
let getemail = emailsData.logemails

let mobile = document.getElementById('mobile').value;
let mobileData = localStorage.getItem('Inmobile');
let mobilesData = JSON.parse(mobileData);
let getmobile = mobilesData.logmobiles

let name = document.getElementById('name').value;
let nameData = localStorage.getItem('Innames');
let namesData = JSON.parse(nameData);
let getname = namesData.logname

let age = document.getElementById('age').value;
let ageData = localStorage.getItem('Inage');
let agesData = JSON.parse(ageData);
let getage = agesData.logages

let dob = document.getElementById('dob').value;
let dobData = localStorage.getItem('Indob');
let dobsData = JSON.parse(dobData);
let getdob = dobsData.logdob

document.getElementById('name').innerHTML = getname;
document.getElementById('mobile').innerHTML = getmobile;
document.getElementById('email').innerHTML = getemail;
document.getElementById('age').innerHTML = getage;
document.getElementById('dob').innerHTML = getdob;
// ===========================================================================================
function logout(){
    alert("Logout Successful");
    window.location.href = 'signup.html';
}
// ===========================================================================================
